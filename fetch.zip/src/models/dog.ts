export type Dog = {
  id: string;
  name: string;
  img: string;
  breed: string;
  age: string;
  zip_code: string;
};
